<?php $__env->startSection('content'); ?>
    <h1>Posts</h1>

    <a href="/posts" class="btn btn-outline-dark">Go Back</a>
    <h1><?php echo e($posts->title); ?></h1>
    <img style="width: 100%" src="/storage/cover_images/<?php echo e($posts->cover_image); ?>">

    <br><br>
    <div>
        <?php echo $posts->body; ?>

    </div>
    <hr>

    <small>Written on <?php echo e($posts->created_at); ?> by <b><?php echo e($posts->user->name); ?></b></small>


    <hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $posts->user_id): ?>
            <a href="/posts/<?php echo e($posts->id); ?>/edit" class="btn btn-secondary">Edit</a>
            <?php echo Form::open(['action'=> ['App\Http\Controllers\PostsController@destroy', $posts->id], 'method'=>'POST', 'class'=>'float-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>


            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraproxy\resources\views/posts/show.blade.php ENDPATH**/ ?>