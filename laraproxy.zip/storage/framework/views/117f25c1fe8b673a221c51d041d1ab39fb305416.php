<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<body><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e('css/app.css'); ?>">
    <title><?php echo e(config('app_name', 'LaraProxy')); ?></title>

</head>

<?php echo $__env->make('posts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container pt-1">

    <?php echo $__env->yieldContent('contents'); ?>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laraproxy\resources\views/posts/base.blade.php ENDPATH**/ ?>