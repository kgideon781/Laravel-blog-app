<link rel="stylesheet" href="<?php echo e('css/app.css'); ?>">
<?php $__env->startSection('content'); ?>


    <h1>Creation happens here</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraproxy\resources\views/posts/create.blade.php ENDPATH**/ ?>