<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?>


                </div>


                <div class="card-body">
                    <a href="/posts/create" class="btn btn-primary mb-4">Create post</a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>


                        </div>
                    <?php endif; ?>

                    <br>
                    <h1>Your blog posts here!</h1>

                    <?php if(count($posts) > 0): ?>
                        <table class="table table-striped">
                            <tr>
                                <td>Title</td>
                                <td></td>
                                <td></td>

                            </tr>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($post->title); ?></th>
                                    <td><a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary">Edit</a></td>
                                    <td>
                                        <?php echo Form::open(['action'=> ['App\Http\Controllers\PostsController@destroy', $post->id], 'method'=>'POST', 'class'=>'float-right']); ?>

                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>


                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    <?php else: ?>
                        <p>You have no posts yet!</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraproxy\resources\views/home.blade.php ENDPATH**/ ?>