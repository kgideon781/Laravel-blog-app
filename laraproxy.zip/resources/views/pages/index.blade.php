@extends('layouts.app')

@section('content')
<div class="jumbotron text-center">
<h1>Welcome to LaraProxy</h1>
<p>This a web series on Laravel Framework, <br>
it is the third video in the series 
</p>
<p><a class="btn btn-primary btn-lg" href="/login" role="button">Login</a>
<a class="btn btn-success btn-lg" href="/register" role="button">Register</a></p>
</div>
@endsection

